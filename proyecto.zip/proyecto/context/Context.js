import { createContext, useState } from 'react';
const Context = createContext();
export const Provider = ({ children }) => {
const [counter, setCounter] = useState(0);
return (
<Context.Provider value={{ counter, setCounter }}>
{children}
</Context.Provider>
);
};
export default Context;