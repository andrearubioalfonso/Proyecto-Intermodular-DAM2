import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';

import Screen1 from './screens/screen1/Login';
import Screen2 from './screens/screen2/Register';
import Home from './screens/screen3/Home';
import Reminder from './screens/screen5/Reminder';
import Maintenance from './screens/screen6/Maintenance';
import Vehicle from './screens/screen4/AddVehicle';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const MenuLateral = () => (
<Tab.Navigator screenOptions={{ headerShown: false }}>
<Tab.Screen name="Home" component={Home} />
<Tab.Screen name="Reminder" component={Reminder} />
<Tab.Screen name="Maintenance" component={Maintenance} />
</Tab.Navigator>
);

const App = () => (
<NavigationContainer>
<Stack.Navigator screenOptions={{ headerShown: false }}>
<Stack.Screen name="Log In" component={Screen1} />
<Stack.Screen name="Register" component={Screen2} />
<Stack.Screen name="Home" component={MenuLateral} />
<Stack.Screen name="AddVehicle" component={Vehicle} />
</Stack.Navigator>
</NavigationContainer>
);


export default App;